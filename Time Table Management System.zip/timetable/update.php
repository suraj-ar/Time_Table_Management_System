<?php
session_start();
$d=$_SESSION["Duration"];
//echo $_SESSION["Duration"];
$sem = $_SESSION['sem'];
$a=$_SESSION['sub'];
$b=$_SESSION['day'];
$c=$_SESSION['start'];
$db = new mysqli('localhost', 'root', '',  'timetable') or die("Unable to connect");
$strSQL1="DELETE FROM  teaches WHERE teaches.Day='$b' AND teaches.Start_Time='$c' AND teaches.Semester='$sem'";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error40');
if($a=='ELEC-A')
{
	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS5A1', 'AA',SS', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');

	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS5A2','SC', 'KSN', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error42');

	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS5A5', 'MIS', SRN', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error43');

	
}

elseif($a=='ELEC-B')
{
	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS5B1','GT', 'SGR', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error44');

	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS5B5', 'JAVA',PT', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error45');

	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS5B6', 'NLP',BMS', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error46');

}
elseif($a=='ELEC-E')
{
	$strSQL1=" INSERT INTO teaches (`Course_Code`, `Sub_Name`,`Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS7E3', 'BDM',GRS', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error47');

	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS7E4', 'CCA',PT', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error47');

	$strSQL1=" INSERT INTO teaches (`Course_Code`, `Sub_Name`,`Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS7E6', 'FLGA',SGR', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error48');

}

else
{
	$strSQL1="SELECT DISTINCT teaches.Course_Code,teaches.Short_Name,teaches.Venue FROM teaches,faculty WHERE faculty.Short_Name = teaches.Short_Name AND teaches.Sub_Name='$a'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error49');
	$row2 = mysqli_fetch_assoc($result3);
	$course=$row2['Course_Code'];
	$venue=$row2['Venue'];
	$fac=$row2['Short_Name'];
	//echo $course;
	//echo "r";
	//echo $fac;
	//echo $b;
	//echo $c;
	//echo $d;
	if($fac==Null)
	{
		$fac='Null';
	}
	if($venue==Null)
	{
		$venue='Null';
	}
	if($course==Null)
	{
		$course='Null';
	}
	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`,`Venue`, `Start_Time`,  `Semester`, `Duration`) VALUES ('$course','$a', '$fac', '$b', '$venue','$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error50');
}
?>

<html>
<head>
   <title></title>
</head>
<body style="width: 100%; height: 100%;background-image: url('img/bgimg6.jpg');height: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;"> <td>
 <div style="padding-top:250px;  padding-left: 200px; float = left ; position: absolute;">
<h2>The changes have been made to the database<h2>
	<div/>


<body/>
<html/>
























