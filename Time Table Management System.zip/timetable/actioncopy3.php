<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"  xmlns:lang="kn" dir="ltr">
<head>
    <title>Search</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style>
	.outer{
		color: red;
		width: 1500px;
		height: 800px;
		float: right;
		text-align: center;
		}
	
	.admin{
		color:white;
		magin-left: 25px;
		margin-top:150px;
	      }
	.exit{
		color:white;
		magin-left: 25px;
	      }
	
	.tt{
		width:250px;
		height:50px;
		margin-top:300px;
		}


ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}

	
    </style>
</head>
<body style="width: 100%; height: 100%; background: url('img/bgimg3.jpg');background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
    <ul>
  <li><a class="active" href="index.php">Home</a></li>

</ul>
    <div class = "outer">
		<form action="facultycopy.php" method="post">
			<input type="submit" class="button" value="submit" />
			<select class = "tt" name="fname">
				<option value="PT">Padmashree T</option>
				<option value="RMS">Rajshekar Murthy S</option>
				<option value="GV">Geetha V</option>
				<option value="CRM">Chethana Murthy R</option>
				<option value="BKS">Srinivas B K</option>
				<option value="MM">Merin Meleet</option>
				<option value="SGR">Raghavendra Prasad S</option>
				<option value="GRS">Smitha G R</option>
				<option value="SS">Swetha S</option>
				<option value="GSM">Mamatha G S</option>
				<option value="DP">Priya D</option>
				<option value="RBS">Rekha B S</option>
				<option value="ABS">Anisha B S</option>
				<option value="NKC">Cauvery N K</option>
				<option value="RR">Rashmi R</option>
				<option value="VK">Vanishree K</option>
				<option value="SRN">Shantaram Nayak</option>
				<option value="GCN">Nagaraj G Choli</option>
				<option value="KSN">Kavitha S N</option>
				<option value="GNS">Srinivasan G N</option>
				<option value="BMS">Sagar B M</option>
				<option value="SN">Sushmitha N</option>
				
			</select>
			
		</form>
			

		
</div>
		
		
  	</div>  
</body>
</html>