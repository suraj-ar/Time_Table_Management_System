<?php
$username="";
$p1=0;
$p2=1;
$p=1;
if(isset($_POST['user1']) && isset($_POST['psw1']))
{
		#$pass = $_POST['psw']; 
		$username = $_POST['user1'];
		#$cpass = $_POST['cpsw']; 
		if(empty($_POST['user1']) || empty($_POST['psw1'])){
			$p2=0;

		}
		else
		{
			if($p2==1)
			{
				$db = new mysqli('localhost', 'root', '', 'timetable') or die("Unable to connect");
				$user = (string)$_POST['user1'];
				$password = (string)$_POST['psw1'];
				$strSQL4 =" SELECT * FROM user";
				$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
				while($row3= mysqli_fetch_assoc($result3))
				{
				 if(strcmp($row3['username'], $user)==0  && strcmp($row3['password'], $password)==0)
				 {
				 	$p1=1;
				 	
				 }
				}
				if($p1==1){
					header("Location:adminlanding.php");
				}
				else
				{
					$p=0;
				}
			}
			
		}

}
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"  xmlns:lang="kn" dir="ltr">
<head>
    <title>Search</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->

    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body style="background-color: black">
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('img/bgimg5.jpg');height: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
			<div class="wrap-login100 p-t-30 p-b-50">
				<span class="login100-form-title p-b-41">
					Account Login
				</span>
				<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">

					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<input type="text" 
			name="user1"
			value="<?php echo $username; ?>" 
			size=40
			style="height:30px;
			  width:300px;
			font-size:14pt;"/>
						<span class="focus-input100" data-placeholder="&#xe82a;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input type="password" 
			name="psw1"
			size=40
			style="height:30px;
			  width:300px;
			font-size:14pt;"/>
						<span class="focus-input100" data-placeholder="&#xe80f;"></span>
					</div>

					<div class="container-login100-form-btn m-t-32">
						
						<button class="login100-form-btn"  type="submit" value="Submit">
							LOGIN
						</button>
					</div>

    <br/>
	<br/>

	<?php
	if ($p2==0) {
		?>
	<h1>Please don't be lazy and fill everything<h1>	
		<?php
	}
	if ($p1==0 && $p==0) {
		?>
	<h1>CHOR CHOR CHOR!!!!!<h1>	
		<?php
	}
	?>
  				</form>
			</div>
		</div>
	</div>
  <a href= "login2.php"><button style="width: 100px; height: 50px; color: white; border-radius: 15px; margin:auto;
  display:block;">Create another Admin ID </button></a>
</div>

<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>


</body>
</html>