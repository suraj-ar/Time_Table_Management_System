
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"  xmlns:lang="kn" dir="ltr">
<head>
    <title>Search</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style>
	.outer{
		color: red;
		width: 1200px;
		height: 800px;
		float: right;
		text-align: center;
		background: white;
		}
	
	.admin{
		color:white;
		magin-left: 25px;
		margin-top:150px;
	      }
	.exit{
		color:white;
		magin-left:10px;
	      }
	
	.tt{
		width:250px;
		height:50px;
		margin-top:75px;
		}
	.tt1{
		width:250px;
		height:50px;
		margin-top:25px;
		}
		ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}

	
	
    </style>
</head>
<body style="width: 100%; background-image: url('img/bgimg6.jpg');height: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
     <ul>
  <li><a class="active" href="adminlanding.php">Home</a></li>

</ul>
    <div style="top: 10%; left: 30%; position: absolute;">
    	<h2>Select Value to be changed</h2>
		<form action="time.php" method="post">
			
			<select  class="tt" name="semester">
				<option value="1">1st-Semester</option>
				<option value="3">3rd-Semester</option>
				<option value="5">5th-Semester</option>
				<option value="7">7th-Semester</option>
			</select>
			<br/>
			<br/>

			
			<select  class="tt1" name="day1">
				<option value="Monday">Monday</option>
				<option value="Tuesday">Tuesday</option>
				<option value="Wednesday">Wednesday</option>
				<option value="Thursday">Thursday</option>
				<option value="Friday">Friday</option>
			</select>
			<br/>
			<br/>
			
			
			
			
			<input type="submit" value="Submit">
			<br/>
			<br/>
		
</div>
		
		
  	</div>  
</body>
</html>