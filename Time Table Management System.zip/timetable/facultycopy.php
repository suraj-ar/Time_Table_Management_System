<?php
$query = $_POST['fname'] ;
$fname = explode(" ", $query);
//echo $fname[0];
$db = new mysqli('localhost', 'root', '', 'timetable') or die("Unable to connect");
?>
<html>
<head>
   <title>Start_Time table</title>
</head>
<body style="width: 100%; height: 150%; background: url('img/bgimg4.jpg');background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
<H1><FONT COLOR="DARKCYAN"><CENTER><?php echo $query;?></FONT></H1>
<table border="2" cellspacing="3" align="center">
<tr>
 <td align="center">
 <td>9:00-10:00
 <td>10:00-11:00
 <td>11:00-11:30
 <td>11:30-12:30
 <td>12:30-1:30
 <td>1:30-2:15
 <td>2:15-3:15
 <td>3:15-4:15
</tr>
<tr>
 <td align="center">
 <td>9:00-10:00
 <td>10:00-11:00
 <td>11:30-12:00
 <td>12:00-1:00
 <td>1:00-2:00
 <td>2:00-2:45
 <td>2:45-3:45
 <td>3:45-4:45
</tr>

<tr>
 <td rowspan="2"align="center">MONDAY
 <?php
 $strSQL1 ="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
 //$strSQL2="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 //$strSQL3="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	<td rowspan="10"align="center">B<br>R<br>E<br>A<br>K
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<td rowspan="10"align="center">L<br>U<br>N<br>C<br>H
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}

	?>
	<tr>
	<td colspan = "2" align="center"><font color="black"><?php echo $row1['Sub_Name']; echo $row1['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '10:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<td rowspan="10"align="center">B<br>R<br>E<br>A<br>K
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '11:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<td rowspan="10"align="center">L<br>U<br>N<br>C<br>H
		<?php

	


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php




	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php

 }	
?>


<tr>
 <td rowspan="2"align="center">TUESDAY
 <?php
 $strSQL1 ="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
 //$strSQL2="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 //$strSQL3="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}

	?>
	<tr>
	<td colspan = "2" align="center"><font color="black"><?php echo $row1['Sub_Name']; echo $row1['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '10:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>

		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '11:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php
	}
	else
	{
		?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<?php
	}
	?>
		<?php

	


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php




	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php

 }	
?>


<tr>
 <td rowspan="2"align="center">WEDNESDAY
 <?php
 $strSQL1 ="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
 //$strSQL2="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 //$strSQL3="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}

	?>
	<tr>
	<td colspan = "2" align="center"><font color="black"><?php echo $row1['Sub_Name']; echo $row1['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '10:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '11:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php
	}
	else
	{
		?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<?php
	}
	?>
		<?php

	


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php




	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php

 }	
?>


<tr>
 <td rowspan="2"align="center">THURSDAY
 <?php
 $strSQL1 ="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
 //$strSQL2="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 //$strSQL3="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}

	?>
	<tr>
	<td colspan = "2" align="center"><font color="black"><?php echo $row1['Sub_Name']; echo $row1['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '10:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '11:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php
	}
	else
	{
		?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<?php
	}
	?>
		<?php

	

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php




	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php

 }	
?>


<tr>
 <td rowspan="2"align="center">FRIDAY
 <?php
 $strSQL1 ="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
 //$strSQL2="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 //$strSQL3="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}

	?>
	<tr>
	<td colspan = "2" align="center"><font color="black"><?php echo $row1['Sub_Name']; echo $row1['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '10:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '11:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php
	}
	else
	{
		?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<?php
	}
	?>
		<?php

	

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php




	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php

 }	
?>

</table>
<br>
<br>
<br>
<H3><FONT COLOR="BLACK"><CENTER><?php echo "WORKLOAD";?></FONT></H3>

<table border="1" cellspacing="2" align="center">
<tr>
	<th>Responsibility</th>
	<th>Credits</th>
</tr>


	<?php


	$strSQL1 =" SELECT (2*count(t.Duration)) Theory from teaches as t where t.Duration = '1' and t.Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row4 = mysqli_fetch_assoc($result3);
	?>
	<tr>	
	<td><font color="black">Theory</font></td>
	<td><font color="black"><?php echo $row4['Theory'];  ?></font></td> <br> 
	</tr>


	<?php


	$strSQL1 =" SELECT (3*count(t.Duration)) Lab from teaches as t where t.Duration = '2.5' and t.Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row4 = mysqli_fetch_assoc($result3);
	?>
	<tr>	
	<td ><font color="black">Lab</font></td>
	<td ><font color="black"><?php echo $row4['Lab']; ?></font></td> <br> 
	</tr>

	<?php


	$strSQL1 =" SELECT  w.Name from workload as w where w.Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row4 = mysqli_fetch_assoc($result3);
	?>
		
	<td><font color="black"><?php while($row = mysqli_fetch_array($result3)) {  echo $row['Name']; ?> <br> <?php } ?></font></td>  
	
	<?php


	$strSQL2 =" SELECT  w.Credits from workload as w where w.Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL2) or die('SQL Error4');
	//$row4 = mysqli_fetch_assoc($result3);
	?>
		
	<td ><font color="black"><?php while($row = mysqli_fetch_array($result3)) {  echo $row['Credits']; ?> <br> <?php } ?></font></td>  
	

	<?php


	$strSQL1 ="  SELECT  SUM(totalcredits) Total_Credits
FROM
        ( 
            select (2*count(t.Duration)) totalcredits from teaches as t where t.Duration = '1' and t.Short_Name = '$fname[0]' 
            UNION ALL
            select (3*count(t.Duration)) totallcredits from teaches as t where t.Duration = '2.5' and t.Short_Name = '$fname[0]' 
            UNION ALL
            select w.Credits totalcredits from workload as w where w.Short_Name = '$fname[0]'
            )s";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row4 = mysqli_fetch_assoc($result3);
	?>
	<tr>	
	<td><font color="black">Total Credits</font></td>
	<td><font color="black"><?php echo $row4['Total_Credits']; ?></font></td> <br> 
	</tr>
</table>

</body>
</html> 
