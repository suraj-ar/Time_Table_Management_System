<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"  xmlns:lang="kn" dir="ltr">
<head>
    <title>Search</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style>
	.outer{
		color: red;
		width: 1500px;
		height: 800px;
		float: right;
		text-align: center;
		}
	
	.admin{
		color:white;
		magin-left: 25px;
		margin-top:150px;
	      }
	.exit{
		color:white;
		magin-left: 25px;
	      }
	
	.tt{
		width:250px;
		height:50px;
		margin-top:300px;
		}


ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}

	
    </style>
</head>
<body style="width: 100%; height: 100%; background: url('img/bgimg2.jpg');background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
    <ul>
  <li><a class="active" href="index.php">Home</a></li>

</ul>
    <div class = "outer">
		<form action="daycopy.php" method="post">
			<input type="submit"  class ="button" value="submit" />
			<select  class="tt" name="day">
				<option value="actioncopy2.php">Select a Day</option>
				<option value="MONDAY">Monday</option>
				<option value="TUESDAY">Tuesday</option>
				<option value="WEDNESDAY">Wednesday</option>
				<option value="THURSDAY">Thursday</option>
				<option value="FRIDAY">Friday</option>
			</select>
			

		
</div>
		
		
  	</div>  
</body>
</html>