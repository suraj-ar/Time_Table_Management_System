<?php
session_start();
$username="";
$p1=0;
$p2=1;
$p=1;
if(isset($_POST['user2']) && isset($_POST['psw2']))
{
		#$pass = $_POST['psw']; 
		$username = $_POST['user2'];
		#$cpass = $_POST['cpsw']; 
		if(empty($_POST['user2']) || empty($_POST['psw2'])){
			$p2=0;

		}
		else
		{
			if($p2==1)
			{
				$db = new mysqli('localhost', 'root', '', 'timetable') or die("Unable to connect");
				$user = $_POST['user2'];
				$SESSION['users'] = mysqli_real_escape_string($db, $user);
				$password = $_POST['psw2'];
				$user=$SESSION['users'];

				$strSQL4 =" SELECT * FROM user";
				$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
				while($row3= mysqli_fetch_assoc($result3))
				{
				 if(strcmp($row3['username'], $user)==0  && strcmp($row3['password'], $password)==0)
				 {
				 	$p1=1;
				 	
				 }
				}
				if($p1==1){
					header("Location:signin.php");
				}
				else
				{
					$p=0;
				}
			}
			
		}

}
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"  xmlns:lang="kn" dir="ltr">
<head>
    <title>Search</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body style="width: 100%; height: 100%; background-image: url('img/bgimg1.jpg');height: 100%;background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
<div style="top: 20%; left: 30%; position: absolute;">
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
  	<p><h3 style="color: white">Enter the username</h3>
		<p><input 
			type="text" 
			name="user2"
			value="<?php echo $username; ?>" 
			size=40
			style="height:30px;
			  width:300px;
			font-size:14pt;"/>
    <br/>
	<br/>
    <p><h3 style="color: white">Enter the password</h3>
		<p><input 
			type="password" 
			name="psw2"
			size=40
			style="height:30px;
			  width:300px;
			font-size:14pt;"/>
			<input type="submit" value="Submit">
    <br/>
	<br/>
	<?php
	if ($p2==0) {
		?>
	<h1 style="color: white">Please fill in all the details..<h1>	
		<?php
	}
	if ($p1==0 && $p==0) {
		?>
	<h1 style="color: white">Incorrect Username or password..<h1>	
		<?php
	}
	?>
  </form>
</div>
</body>
</html>