
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>HOD</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="generator" content="Codeply">
    <link rel="stylesheet" href="./css3/bootstrap.min.css" />
    <link rel="stylesheet" href="./css3/animate.min.css" />
    <link rel="stylesheet" href="./css3/ionicons.min.css" />
    <link rel="stylesheet" href="./css3/styles.css" />
  </head>
  <body>
    <nav id="topNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="navbar-collapse collapse" id="bs-navbar">
                <ul class="nav navbar-nav">
                    <li>
                        <a class="page-scroll" href="adminlanding.php">Home Page</a>
                    </li>

                </ul>
            </div>
        </div>
    </nav>
    <header id="first">
        <div class="header-content">
            <div class="inner">
                <h1 class="cursive">WELCOME TO THE VIEW SECTION OF TIMETABLE MANAGEMENT SYSTEM</h1>
                <h4>Please select the type of time-table you want to view</h4>
                <hr>
                <a href="actioncopy3.php" class="btn btn-primary btn-xl">Faculty Wise</a> &nbsp; <a href="actioncopy2.php" class="btn btn-primary btn-xl">Consolidated</a>
            </div>
        </div>

    </header>
    <!--scripts loaded here -->
    <script src="./js1/jquery.min.js"></script>
    <script src="./js1/bootstrap.min.js"></script>
    <script src="./js1/jquery.easing.min.js"></script>
    <script src="./js1/wow.js"></script>
    <script src="./js1/scripts.js"></script>
  </body>
</html>