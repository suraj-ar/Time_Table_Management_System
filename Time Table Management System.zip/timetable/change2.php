<?php
session_start();
$_SESSION['sub'] = $_POST['sub'];
$a=$_SESSION['sub'];
$b=$_SESSION['day'];
$c=$_SESSION['start'];
//echo $a;
//echo $b;
//echo $c;
//echo $_SESSION["sem"];
$p=0;
$d=0;
$db = new mysqli('localhost', 'root', '', 'timetable') or die("Unable to connect");
if($a=='ELEC-A')
{
	$strSQL1 =" SELECT subjects.Sub_Name,teaches.Sub_Name from subjects,teaches WHERE subjects.Course_Code = teaches.Course_Code and faculty.Short_Name = teaches.Short_Name and teaches.Day = '$b' and teaches.Start_Time = '$c' and faculty.Short_Name IN (SELECT DISTINCT teaches.Short_Name  FROM subjects,teaches WHERE subjects.Course_Code = teaches.Course_Code AND teaches.Sub_Name IN (SELECT teaches.Sub_Name FROM subjects WHERE teaches.Sub_Name='AA'OR teaches.Sub_Name = 'SC' OR teaches.Sub_Name='MIS'))";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row2 = mysqli_fetch_assoc($result3);
if (mysqli_num_rows($result3)!=0) {
	$p=1;
}
$x=$row2['Sub_Name'];
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = 'AA'";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row3 = mysqli_fetch_assoc($result3);
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = '$x'";
$result4 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row4= mysqli_fetch_assoc($result4);
if($p==1 && $row3['Semester']==$row4['Semester'])
{
	$p=0;
}
}


elseif($a=='ELEC-B')
{
	$strSQL1 ="SELECT subjects.Sub_Name,teaches.Sub_Name from subjects,teaches WHERE subjects.Course_Code = teaches.Course_Code and faculty.Short_Name = teaches.Short_Name and teaches.Day = '$b' and teaches.Start_Time = '$c' and faculty.Short_Name IN (SELECT DISTINCT teaches.Short_Name  FROM subjects,teaches WHERE subjects.Course_Code = teaches.Course_Code AND teaches.Sub_Name IN (SELECT teaches.Sub_Name FROM subjects WHERE teaches.Sub_Name = 'GT' OR teaches.Sub_Name='JAVA' OR teaches.Sub_Name='NLP'))";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error401');
if (mysqli_num_rows($result3)!=0) {
	$p=1;
}
$row2 = mysqli_fetch_assoc($result3);
$x=$row2['Sub_Name'];
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = 'GT'";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row3 = mysqli_fetch_assoc($result3);
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = '$x'";
$result4 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row4= mysqli_fetch_assoc($result4);
if($p==1 && $row3['Semester']==$row4['Semester'])
{
	$p=0;
}
}

elseif($a=='ELEC-E')
{
	$strSQL1 ="SELECT subjects.Sub_Name,teaches.Sub_Name from subjects,teaches WHERE subjects.Course_Code = teaches.Course_Code and faculty.Short_Name = teaches.Short_Name and teaches.Day = '$b' and teaches.Start_Time = '$c' and faculty.Short_Name IN (SELECT DISTINCT teaches.Short_Name  FROM subjects,teaches WHERE subjects.Course_Code = teaches.Course_Code AND teaches.Sub_Name IN (SELECT teaches.Sub_Name FROM subjects WHERE teaches.Sub_Name = 'BDM' OR teaches.Sub_Name='CCA' OR teaches.Sub_Name='FLGA'))";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error401');
if (mysqli_num_rows($result3)!=0) {
	$p=1;
}
$row2 = mysqli_fetch_assoc($result3);
$x=$row2['Sub_Name'];
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = 'BDM'";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row3 = mysqli_fetch_assoc($result3);
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = '$x'";
$result4 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row4= mysqli_fetch_assoc($result4);
if($p==1 && $row3['Semester']==$row4['Semester'])
{
	$p=0;
}
}


else
{
	$strSQL1 =" SELECT teaches.Sub_Name from subjects,teaches,faculty WHERE subjects.Course_Code = teaches.Course_Code and faculty.Short_Name = teaches.Short_Name and teaches.Day = '$b' and teaches.Start_Time = '$c' and faculty.Short_Name IN (SELECT DISTINCT teaches.Short_Name FROM subjects,teaches,faculty WHERE subjects.Course_Code = teaches.Course_Code AND teaches.Sub_Name='$a')";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error431');
$row2 = mysqli_fetch_assoc($result3);
if (mysqli_num_rows($result3)!=0) {
	$p=1;
}
$x=$row2['Sub_Name'];
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = '$a'";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row3 = mysqli_fetch_assoc($result3);
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = '$x'";
$result4 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row4= mysqli_fetch_assoc($result4);
if($p==1 && $row3['Semester']==$row4['Semester'])
{
	$p=0;
}
}




if($_SESSION["Duration"]==1)
{
	$d=1;
}
//if($d==1)
//{
//	$strSQL1 =" SELECT ADDTIME('$_SESSION['start']', '01:00:00')";
//	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
//	$row = mysqli_fetch_assoc($result3);
//}
//else
//{
//	$strSQL1 =" SELECT ADDTIME('$_SESSION['start']', '02:30:00')";
//	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
//	$row = mysqli_fetch_assoc($result3);
//}

if($p==0)
{
	?>
	<html>
<head>
   <title></title>
</head>
<body style="width: 100%; height: 100%;background-image: url('img/bgimg6.jpg');height: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;"> <td>
 <div style="padding-top:50px;  padding-left: 100px; float = left ; position: absolute;">
<h2>Do you want to implement the following change to the Database?<h2>
	<div/>
	<br/>
	<br/>
<div style="padding-top:50px;  padding-left: 350px; float = left ; position: absolute;">
<H1><FONT COLOR="DARKCYAN"><CENTER></FONT></H1>
<table border="2" cellspacing="3" align="center">
<tr>
 <td>DAY
 <td>START-TIME
 <td>DURATION
 <td>SUBJECT
 
 
</tr>
<tr>
 <td><?php echo $_SESSION['day']?>
 <td><?php echo $_SESSION['start']?>
 <td><?php echo $_SESSION['Duration']?>
 <td><?php echo $_SESSION['sub']?>

</tr>
<div/>
<div style="  padding-left: 400px; position: absolute;">
	<br/>
<a href= "admin.php"><button style="width: 75px; height: 30px; color: black; border-radius: 15px;">Cancel</button></a>
<form action="update.php" method="post" style="height:30px; width:150px; font-size:14pt;  padding-left: 320px;">
	<input type="submit" value="Submit">

			<br/>
			<br/>
<div/>
</body>
</html>	
<?php
}
else
{
	?>
<html>
<head>
   <title></title>
</head>
<body bgcolor="skyblue"> <td>
<h3>Cannot make the updation to the time table.<br/><?php echo $row2['Sub_Name'] ;?> who is scheduled to handle <?php echo $a ;?> is already handling the class <?php echo $row2['Sub_Name'] ;?> at <?php echo $c;?> on <?php echo $b;?>.<h3>

</body>
</html>	
<?php
}
?>