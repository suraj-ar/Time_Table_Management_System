<?php
// Starting session
session_start();
 
// Storing session data
$_SESSION['sem'] = $_POST['semester'];
$_SESSION['day'] = $_POST['day1'];
$username="";
$p=0;
$p1=0;
//$p2=1;
$sem = $_POST['semester'];
$day = $_POST['day1'];
//$start = $_POST['start'];
//$a=array();
//$b=array();
$db = new mysqli('localhost', 'root', '', 'timetable') or die("Unable to connect");
$strSQL1 =" SELECT DISTINCT teaches.Duration FROM teaches WHERE teaches.Day = '$day' AND teaches.Semester = '$sem'";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
//$row3= mysqli_fetch_assoc($result3)
if (mysqli_num_rows($result3)==1) {
	$p=1;
}
else
{
	$strSQL1 =" SELECT DISTINCT teaches.Duration FROM teaches WHERE teaches.Day = '$day' AND teaches.Semester = '$sem'  AND teaches.Start_Time='09:00'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3= mysqli_fetch_assoc($result3);
	if($row3['Duration']==2.5)
	{
		$p1=1;
	}
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"  xmlns:lang="kn" dir="ltr">
<head>
    <title>Search</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style>
	.outer{
		color: red;
		width: 1200px;
		height: 800px;
		float: right;
		text-align: center;
		background: white;
		}
	
	.admin{
		color:white;
		magin-left: 25px;
		margin-top:150px;
	      }
	.exit{
		color:white;
		magin-left:10px;
	      }
	
	.tt1{
		width:250px;
		height:50px;
		margin-top:25px;
		}
	.tt2{
		width:250px;
		height:50px;
		margin-top:25px;
		}
	.tt{
		width:250px;
		height:50px;
		margin-top:25px;
		}
		ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}

	
    </style>
</head>
<body style="width: 100%; height: 100%;background-image: url('img/bgimg6.jpg');height: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
 <ul>
  <li><a class="active" href="adminlogin.php">Home</a></li>

</ul>
    <?php
    if($p==1)
    {
    	?>
    	<div style="top: 10%; left: 50%; position: absolute;">
    	<h2>Select starting time</h2>
		<form action="change.php" method="post">
			<select  class="tt2" name="start">
				
				<option value="09:00">09:00</option>
				<option value="10:00">10:00</option>
				<option value="11:30">11:30</option>
				<option value="12:30">12:30</option>
				<option value="02:15">02:15</option>
				<option value="03:15">03:15</option>
			</select>
			<br/>
			<br/>
		<?php
    }
    if($p==0 && $p1==1)
    {
    	?>
    	<div style="top: 10%; left: 50%; position: absolute;">
   		<h2>Select starting time</h2>
		<form action="change.php" method="post">
			<select  class="tt1" name="start">
				
				<option value="12:00">12:00</option>
				<option value="01:00">01:00</option>
				<option value="02:45">02:45</option>
				<option value="03:45">03:45</option>
			</select>
			<br/>
			<br/>
		<?php
    }
    if($p==0 && $p1==0)
    {
    	?>
    <div style="top: 10%; left: 50%; position: absolute;">
    	<h2>Select starting time</h2>
		<form action="change.php" method="post">
			
			<select  class="tt" name="start">
				
				<option value="09:00">09:00</option>
				<option value="10:00">10:00</option>
				<option value="11:30">11:30</option>
				<option value="12:30">12:30</option>
				
			</select>
			<br/>
			<br/>
		<?php	
	}
	?>
	<input type="submit" value="Submit">
			<br/>
			<br/>
		
</div>
		
		
  	</div>  
</body>
</html>

