<?php
$query = $_POST['day'] ;
//$fname = explode(" ", 4);
//echo $fname[0];
$db = new mysqli('localhost', 'root', '', 'timetable') or die("Unable to connect");
?>
<html>
<head>
   <title>Start_Time table</title>
</head>
<body style="width: 100%; height: 200%; background: url('img/bgimg4.jpg');background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
<H1><FONT COLOR="DARKCYAN"><CENTER><?php echo $query;?> TIMETABLE</FONT></H1>
<table border="2" cellspacing="3" align="center">
<tr>
 <td align="center">
 <td>09:00-10:00
 <td>10:00-11:00
 <td>11:00-11:30
 <td>11:30-12:30
 <td>12:30-01:30
 <td>01:30-02:15
 <td>02:15-03:15
 <td>03:15-04:15
</tr>
<tr>
 <td align="center">
 <td>09:00-10:00
 <td>10:00-11:00
 <td>11:30-12:00
 <td>12:00-01:00
 <td>01:00-02:00
 <td>02:00-02:45
 <td>02:45-03:45
 <td>03:45-04:45
</tr>


<tr>
 <td rowspan="2"align="center">1ST SEM
 <?php
 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE Day = '$query' and Start_Time = '09:00' and Semester = 1";
 //$strSQL2="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 //$strSQL3="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	<td rowspan="10"align="center">B<br>R<br>E<br>A<br>K
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE  Day = '$query' and Start_Time = '12:30' and  Semester = '1'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	<td rowspan="10"align="center">L<br>U<br>N<br>C<br>H
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE Day = '$query' and Start_Time = '02:15' and  Semester = '1'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ; echo $row['Venue']; echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '1')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '1')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		</tr>
		<?php
	}

	 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '1')";
 	 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
	?>

	<tr>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '001:00' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php

	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '10:00' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	<td rowspan="10"align="center">B<br>R<br>E<br>A<br>K
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	<td rowspan="10"align="center">L<br>U<br>N<br>C<br>H
		<?php

	


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '1')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php



	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '001:00' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ; echo $row['Venue'];echo $row['Sub_Name'];echo (" ");} ?><br>
		<?php



	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php




	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php

 }	
?>


<tr>
 <td rowspan="2"align="center">3RD SEM
 <?php
 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = 3)";
 //$strSQL2="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 //$strSQL3="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '3')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '3')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		</tr>
		<?php
	}

	 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '3')";
 	 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
	?>

	<tr>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '001:00' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php

	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '10:00' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	
		<?php

	


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '3')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php



	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '001:00' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php



	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php




	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php

 }	
?>


<tr>
 <td rowspan="2"align="center">5TH SEM
 <?php
 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '5')";
 //$strSQL2="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 //$strSQL3="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '5')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '5')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		</tr>
		<?php
	}

	 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '5')";
 	 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
	?>

	<tr>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '001:00' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php

	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '10:00' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	
		<?php

	


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '5')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php



	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '001:00' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php



	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php




	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php

 }	
?>



<tr>
 <td rowspan="2"align="center">7TH SEM
 <?php
 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '7')";
 //$strSQL2="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 //$strSQL3="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '7')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '7')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		</tr>
		<?php
	}

	 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '7')";
 	 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
	?>

	<tr>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '001:00' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php

	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '10:00' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	
		<?php

	


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '7')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php



	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '001:00' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php



	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
		<?php




	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo (" ");} ?><br>
	</tr>
		<?php

 }	
?>



</body>
</html>
