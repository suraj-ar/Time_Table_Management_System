

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Home</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- Theme CSS -->
    <link href="css/clean-blog.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body style="margin: 0px;
    padding: 0px;">
    <!-- Page Header -->
    <!-- Set your background image for this header on the line below. -->
    <header class="intro-header" style="background-image: url('img/pexels-photo-186635.jpeg.jpg'); height: 470px; width: 100% ; position: relative;
    padding: 2em 1em; no-repeat center ; background-size: cover; opacity: 0.6;border-top: 0px solid #CC0000;">
        <div class="container">
            <div class="row">
                    <div class="post-heading">
                        <center>
                        <h1 style="color:  black ;">WELCOME</h1>
                        </center>
                       <!-- <h2 class="subheading">Problems look Relatively small from 5 miles up</h2>-->
                       <!-- <span class="meta">text <a href="#">text</atext</span>-->
                </div>
            </div>
        </div>
    </header>

    <!-- Post Content -->
    <article>
        <div class="container" style="background-image: url('img/bgimg.jpg');background-origin: content-box;background-size: cover;width: 100% ; position: relative;
    padding: 0em 0em; no-repeat center ;">
            <center><strong><h2 style="color: white">Please Select a Login Type</h2></strong></center>
            <br><br><br><br><br>
<br><br>

           <div class="btn-group btn-group-justified">
  <a href="loginagain.php" class="btn btn-primary" style="height: 20px;">Admin Login</a>
  <a href="actioncopy3.php" class="btn btn-primary" style="height: 20px;">Teacher Login</a>
  <a href="hodlanding.php" class="btn btn-primary" style="height: 20px;">HOD Login</a>
</div>
            <br><br><br>
            <br><br><br>
<br><br><br>
        </div>
    </article>



    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/clean-blog.min.js"></script>

</body>

</html>
