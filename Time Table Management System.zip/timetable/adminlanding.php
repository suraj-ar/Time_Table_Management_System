
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Landing Zero Free Bootstrap Theme with Video</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="generator" content="Codeply">
    <link rel="stylesheet" href="./css2/bootstrap.min.css" />
    <link rel="stylesheet" href="./css2/animate.min.css" />
    <link rel="stylesheet" href="./css2/ionicons.min.css" />
    <link rel="stylesheet" href="./css2/styles.css" />
  </head>
  <body>
    <nav id="topNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="navbar-collapse collapse" id="bs-navbar">
                <ul class="nav navbar-nav">
                    <li>
                        <a class="page-scroll" href="index.php">Home Page</a>
                    </li>

                </ul>
            </div>
        </div>
    </nav>
    <header id="first">
        <div class="header-content">
            <div class="inner">
                <h1 class="cursive">Welcome ADMIN!</h1>
                <h4>Please select the action you want to perform</h4>
                <hr>
                <a href="edit.php" class="btn btn-primary btn-xl">Edit Timetable</a> &nbsp; <a href="view.php" class="btn btn-primary btn-xl">View Timetables</a>
            </div>
        </div>

    </header>
    <!--scripts loaded here -->
    <script src="./js1/jquery.min.js"></script>
    <script src="./js1/bootstrap.min.js"></script>
    <script src="./js1/jquery.easing.min.js"></script>
    <script src="./js1/wow.js"></script>
    <script src="./js1/scripts.js"></script>
  </body>
</html>